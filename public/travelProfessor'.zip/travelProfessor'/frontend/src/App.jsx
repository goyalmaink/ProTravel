import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from '../component/Navbar';
import Dashboard from '../component/Dashboard';
import Trips from '../component/Trips';
import Users from '../component/users';
import Media from '../component/Media';
import Reviews from '../component/Reviews';
import Setting from '../component/Setting';
import Blog from '../component/Blog';
const App = () => {
  return (
    <div className="flex">
      <main className="flex-1 p-4">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/trips" element={<Trips />} /> 
          <Route path="/media" element={<Media />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/reviews" element={<Reviews />} />
          <Route path="/users" element={<Users />} />
          <Route path="/settings" element={<Setting />} />
          {/* <Route path="/navbar" element={<Navbar />} /> */}
        </Routes>
      </main>
    </div>
  );
};

export default App;
