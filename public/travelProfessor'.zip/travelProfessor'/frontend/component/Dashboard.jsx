import React, { useState } from 'react';
import { Bell, Plus, Check, Upload, Calendar, MapPin, Users, Settings, MessageSquare, Image, FileText, Star, AlertTriangle, Clock, Info } from 'lucide-react';
import Navbar from './Navbar'; // Assuming you have a Navbar component
const Dashboard = () => {
    const [showNotifications, setShowNotifications] = useState(false);
    const [showAddTripModal, setShowAddTripModal] = useState(false);
    const [showUploadMediaModal, setShowUploadMediaModal] = useState(false);
    const [tripForm, setTripForm] = useState({
        name: '',
        destination: '',
        duration: '',
        price: '',
        description: '',
        difficulty: 'Easy',
        category: 'Adventure'
    });
    const [mediaForm, setMediaForm] = useState({
        title: '',
        description: '',
        category: 'Trip Photos',
        tags: '',
        files: []
    });

    const toggleNotifications = () => {
        setShowNotifications(!showNotifications);
    };

    const handleAddTrip = () => {
        setShowAddTripModal(true);
    };

    const handleUploadMedia = () => {
        setShowUploadMediaModal(true);
    };

    const handleFormChange = (e) => {
        const { name, value } = e.target;
        setTripForm(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleMediaFormChange = (e) => {
        const { name, value } = e.target;
        setMediaForm(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleFileSelect = (e) => {
        const files = Array.from(e.target.files);
        setMediaForm(prev => ({
            ...prev,
            files: files
        }));
    };

    const removeFile = (index) => {
        setMediaForm(prev => ({
            ...prev,
            files: prev.files.filter((_, i) => i !== index)
        }));
    };

    const handleSubmitTrip = (e) => {
        e.preventDefault();
        console.log('New trip submitted:', tripForm);
        alert('Trip added successfully!');
        setShowAddTripModal(false);
        setTripForm({
            name: '',
            destination: '',
            duration: '',
            price: '',
            description: '',
            difficulty: 'Easy',
            category: 'Adventure'
        });
    };

    const handleSubmitMedia = (e) => {
        e.preventDefault();
        console.log('Media uploaded:', mediaForm);
        alert('Media uploaded successfully!');
        setShowUploadMediaModal(false);
        setMediaForm({
            title: '',
            description: '',
            category: 'Trip Photos',
            tags: '',
            files: []
        });
    };

    const closeModal = () => {
        setShowAddTripModal(false);
    };

    const closeMediaModal = () => {
        setShowUploadMediaModal(false);
    };

    const formatFileSize = (bytes) => {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };

    

    const statsData = [
        { title: 'Total Trips', value: '247', change: '+12% from last month', icon: MapPin, color: 'bg-orange-500' },
        { title: 'Bookings', value: '1,832', change: '+8% from last month', icon: Calendar, color: 'bg-green-500' },
        { title: 'Active Users', value: '15,642', change: '+24% from last month', icon: Users, color: 'bg-blue-500' },
        { title: 'Pending Reviews', value: '23', change: 'Needs attention', icon: Star, color: 'bg-yellow-500' },
    ];

    const recentActivity = [
        { icon: Plus, text: 'Trip "Bali Adventure" added by Admin', time: '2 hours ago', color: 'text-orange-500' },
        { icon: Check, text: 'Review approved for "Tokyo Experience"', time: '4 hours ago', color: 'text-green-500' },
        { icon: Upload, text: 'New media uploaded for "Paris Tour"', time: '6 hours ago', color: 'text-blue-500' },
        { icon: Users, text: 'New user registration: Sarah Johnson', time: '8 hours ago', color: 'text-purple-500' },
    ];

    return (
        <div className="min-h-screen bg-gray-50 flex">
            {/* Sidebar */}
            <div className="w-64 bg-white shadow-lg">
                <div className="p-6">
                    <div className="flex items-center space-x-2">
                        <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center">
                            <MapPin className="w-5 h-5 text-white" />
                        </div>
                        <span className="text-xl font-bold text-gray-800">TravelAdmin</span>
                    </div>
                </div>

                <Navbar/>
            </div>

            {/* Main Content */}
            <div className="flex-1  ">
                <header className="bg-white shadow-sm px-8 py-4">
                    <div className="flex items-center justify-between">
                        <div>
                            <h1 className="text-2xl font-bold text-gray-900">Dashboard Overview</h1>
                            <p className="text-gray-600 mt-1">Welcome back, here's what's happening today</p>
                        </div>
                        <div className="flex items-center space-x-4">
                            <div className="relative">
                                <button
                                    onClick={toggleNotifications}
                                    className="relative p-2 text-gray-600 hover:text-gray-900 transition-colors"
                                >
                                    <Bell className="w-6 h-6" />
                                    <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>
                                </button>

                                {showNotifications && (
                                    <div className="absolute right-0 mt-2 w-96 bg-white rounded-lg shadow-xl border border-gray-200 z-50">
                                        <div className="p-4 border-b border-gray-200">
                                            <h3 className="text-lg font-semibold text-gray-900">Alerts & Notifications</h3>
                                        </div>
                                        <div className="p-4 space-y-4">
                                            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                                                <div className="flex items-start space-x-3">
                                                    <AlertTriangle className="w-5 h-5 text-red-500 mt-0.5" />
                                                    <div className="flex-1">
                                                        <h4 className="font-medium text-red-800">Flagged Content</h4>
                                                        <p className="text-red-700 text-sm mt-1">
                                                            Review for "Mountain Trek" contains inappropriate content
                                                        </p>
                                                        <button className="text-red-600 hover:text-red-800 text-sm font-medium mt-2">
                                                            Review Now
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                                                <div className="flex items-start space-x-3">
                                                    <Clock className="w-5 h-5 text-yellow-600 mt-0.5" />
                                                    <div className="flex-1">
                                                        <h4 className="font-medium text-yellow-800">Expiring Offers</h4>
                                                        <p className="text-yellow-700 text-sm mt-1">
                                                            3 promotional offers expire in 2 days
                                                        </p>
                                                        <button className="text-yellow-600 hover:text-yellow-800 text-sm font-medium mt-2">
                                                            Extend Offers
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>

                                            {/* System Update Alert */}
                                            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                                                <div className="flex items-start space-x-3">
                                                    <Info className="w-5 h-5 text-blue-500 mt-0.5" />
                                                    <div className="flex-1">
                                                        <h4 className="font-medium text-blue-800">System Update</h4>
                                                        <p className="text-blue-700 text-sm mt-1">
                                                            Scheduled maintenance tonight at 2:00 AM
                                                        </p>
                                                        <button className="text-blue-600 hover:text-blue-800 text-sm font-medium mt-2">
                                                            View Details
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </div>
                            <div className="flex items-center space-x-3">
                                <div className="text-right">
                                    <p className="text-sm font-medium text-gray-900">Ashwin</p>
                                    <p className="text-xs text-gray-500">Administrator</p>
                                </div>
                                <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
                                    <span className="text-white font-medium text-sm">A</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </header>

                {/* Main Dashboard Content */}
                <main className="flex-1 p-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                        {statsData.map((stat, index) => (
                            <div key={index} className="bg-white rounded-lg shadow-sm p-6">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="text-sm text-gray-600 mb-1">{stat.title}</p>
                                        <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                                        <p className="text-xs text-gray-500 mt-1">{stat.change}</p>
                                    </div>
                                    <div className={`${stat.color} p-3 rounded-lg`}>
                                        <stat.icon className="w-6 h-6 text-white" />
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>

                    {/* Quick Actions */}
                    <div className="mb-8">
                        <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <button
                                onClick={handleAddTrip}
                                className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-3 rounded-lg flex items-center justify-center space-x-2 transition-colors"
                            >
                                <Plus className="w-5 h-5" />
                                <span>Add New Trip</span>
                            </button>
                            <button className="bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg flex items-center justify-center space-x-2 transition-colors">
                                <Check className="w-5 h-5" />
                                <span>Approve Reviews</span>
                            </button>
                            <button
                                onClick={handleUploadMedia}
                                className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg flex items-center justify-center space-x-2 transition-colors"
                            >
                                <Upload className="w-5 h-5" />
                                <span>Upload Media</span>
                            </button>
                        </div>
                    </div>

                    {/* Recent Activity */}
                    <div className="bg-white rounded-lg shadow-sm p-6">
                        <h2 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h2>
                        <div className="space-y-4">
                            {recentActivity.map((activity, index) => (
                                <div key={index} className="flex items-start space-x-3">
                                    <div className={`p-2 rounded-lg ${activity.color} bg-opacity-10`}>
                                        <activity.icon className={`w-4 h-4 ${activity.color}`} />
                                    </div>
                                    <div className="flex-1">
                                        <p className="text-sm text-gray-900">{activity.text}</p>
                                        <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                        <div className="mt-6 text-center">
                            <button className="text-orange-500 hover:text-orange-600 text-sm font-medium">
                                View All Activity
                            </button>
                        </div>
                    </div>
                </main>
            </div>

            {/* Click outside to close notifications */}
            {showNotifications && (
                <div
                    className="fixed inset-0 z-40"
                    onClick={() => setShowNotifications(false)}
                />
            )}

            {/* Add Trip Modal */}
            {showAddTripModal && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                    <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
                        <div className="p-6 border-b border-gray-200">
                            <div className="flex items-center justify-between">
                                <h2 className="text-2xl font-bold text-gray-900">Add New Trip</h2>
                                <button
                                    onClick={closeModal}
                                    className="text-gray-500 hover:text-gray-700"
                                >
                                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <form onSubmit={handleSubmitTrip} className="p-6 space-y-6">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Trip Name *
                                    </label>
                                    <input
                                        type="text"
                                        name="name"
                                        value={tripForm.name}
                                        onChange={handleFormChange}
                                        required
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                                        placeholder="Enter trip name"
                                    />
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Destination *
                                    </label>
                                    <input
                                        type="text"
                                        name="destination"
                                        value={tripForm.destination}
                                        onChange={handleFormChange}
                                        required
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                                        placeholder="Enter destination"
                                    />
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Duration *
                                    </label>
                                    <input
                                        type="text"
                                        name="duration"
                                        value={tripForm.duration}
                                        onChange={handleFormChange}
                                        required
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                                        placeholder="e.g., 5 days, 2 weeks"
                                    />
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Price *
                                    </label>
                                    <input
                                        type="number"
                                        name="price"
                                        value={tripForm.price}
                                        onChange={handleFormChange}
                                        required
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                                        placeholder="Enter price"
                                    />
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Difficulty Level
                                    </label>
                                    <select
                                        name="difficulty"
                                        value={tripForm.difficulty}
                                        onChange={handleFormChange}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                                    >
                                        <option value="Easy">Easy</option>
                                        <option value="Moderate">Moderate</option>
                                        <option value="Challenging">Challenging</option>
                                        <option value="Expert">Expert</option>
                                    </select>
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Category
                                    </label>
                                    <select
                                        name="category"
                                        value={tripForm.category}
                                        onChange={handleFormChange}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                                    >
                                        <option value="Adventure">Adventure</option>
                                        <option value="Cultural">Cultural</option>
                                        <option value="Relaxation">Relaxation</option>
                                        <option value="Wildlife">Wildlife</option>
                                        <option value="Historical">Historical</option>
                                        <option value="Beach">Beach</option>
                                        <option value="Mountain">Mountain</option>
                                    </select>
                                </div>
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Description
                                </label>
                                <textarea
                                    name="description"
                                    value={tripForm.description}
                                    onChange={handleFormChange}
                                    rows={4}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                                    placeholder="Enter trip description"
                                />
                            </div>

                            <div className="flex justify-end space-x-4 pt-6">
                                <button
                                    type="button"
                                    onClick={closeModal}
                                    className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    className="px-6 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition-colors"
                                >
                                    Add Trip
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* Upload Media Modal */}
            {showUploadMediaModal && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                    <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
                        <div className="p-6 border-b border-gray-200">
                            <div className="flex items-center justify-between">
                                <h2 className="text-2xl font-bold text-gray-900">Upload Media</h2>
                                <button
                                    onClick={closeMediaModal}
                                    className="text-gray-500 hover:text-gray-700"
                                >
                                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <form onSubmit={handleSubmitMedia} className="p-6 space-y-6">
                            {/* File Upload Area */}
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Select Files *
                                </label>
                                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
                                    <input
                                        type="file"
                                        multiple
                                        accept="image/*,video/*"
                                        onChange={handleFileSelect}
                                        className="hidden"
                                        id="file-upload"
                                    />
                                    <label htmlFor="file-upload" className="cursor-pointer">
                                        <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                                        <p className="text-lg text-gray-600 mb-2">Click to upload files</p>
                                        <p className="text-sm text-gray-500">or drag and drop</p>
                                        <p className="text-xs text-gray-400 mt-2">PNG, JPG, GIF, MP4, MOV up to 10MB each</p>
                                    </label>
                                </div>
                            </div>

                            {/* Selected Files Preview */}
                            {mediaForm.files.length > 0 && (
                                <div>
                                    <h3 className="text-sm font-medium text-gray-700 mb-3">Selected Files ({mediaForm.files.length})</h3>
                                    <div className="space-y-2 max-h-40 overflow-y-auto">
                                        {mediaForm.files.map((file, index) => (
                                            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                                                <div className="flex items-center space-x-3">
                                                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                                                        {file.type.startsWith('image/') ? (
                                                            <Image className="w-5 h-5 text-blue-600" />
                                                        ) : (
                                                            <Upload className="w-5 h-5 text-blue-600" />
                                                        )}
                                                    </div>
                                                    <div>
                                                        <p className="text-sm font-medium text-gray-900 truncate max-w-xs">
                                                            {file.name}
                                                        </p>
                                                        <p className="text-xs text-gray-500">{formatFileSize(file.size)}</p>
                                                    </div>
                                                </div>
                                                <button
                                                    type="button"
                                                    onClick={() => removeFile(index)}
                                                    className="text-red-500 hover:text-red-700 p-1"
                                                >
                                                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                                    </svg>
                                                </button>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Title *
                                    </label>
                                    <input
                                        type="text"
                                        name="title"
                                        value={mediaForm.title}
                                        onChange={handleMediaFormChange}
                                        required
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                        placeholder="Enter media title"
                                    />
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Category
                                    </label>
                                    <select
                                        name="category"
                                        value={mediaForm.category}
                                        onChange={handleMediaFormChange}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                    >
                                        <option value="Trip Photos">Trip Photos</option>
                                        <option value="Accommodation">Accommodation</option>
                                        <option value="Activities">Activities</option>
                                        <option value="Food & Dining">Food & Dining</option>
                                        <option value="Transportation">Transportation</option>
                                        <option value="Landscapes">Landscapes</option>
                                        <option value="People & Culture">People & Culture</option>
                                        <option value="Promotional">Promotional</option>
                                    </select>
                                </div>
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Tags
                                </label>
                                <input
                                    type="text"
                                    name="tags"
                                    value={mediaForm.tags}
                                    onChange={handleMediaFormChange}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                    placeholder="Enter tags separated by commas (e.g., adventure, mountain, hiking)"
                                />
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Description
                                </label>
                                <textarea
                                    name="description"
                                    value={mediaForm.description}
                                    onChange={handleMediaFormChange}
                                    rows={4}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                    placeholder="Enter media description"
                                />
                            </div>

                            <div className="flex justify-end space-x-4 pt-6">
                                <button
                                    type="button"
                                    onClick={closeMediaModal}
                                    className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    disabled={mediaForm.files.length === 0}
                                    className="px-6 py-2 bg-blue-500 hover:bg-blue-600 disabled:bg-gray-300 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
                                >
                                    Upload Media
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Dashboard;