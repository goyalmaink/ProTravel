import React, { useState } from 'react';
import { Bell, Plus, Check, Upload, Calendar, MapPin, Users, Settings, MessageSquare, Image, FileText, Star, AlertTriangle, Clock, Info, Search, ChevronDown, Eye, Copy, Trash2, Edit, Filter } from 'lucide-react';
import Navbar from './Navbar'; // Assuming you have a Navbar component
const Trips = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedCategory, setSelectedCategory] = useState('All Categories');
    const [selectedStatus, setSelectedStatus] = useState('All Status');
    const [currentPage, setCurrentPage] = useState(1);

    const trips = [
        {
            id: 'TRP-001',
            title: 'Himalayan Adventure',
            description: '14 days trekking experience',
            category: 'Adventure',
            status: 'Active',
            departureDate: '2024-03-15',
            image: '🏔️'
        },
        {
            id: 'TRP-002',
            title: 'European City Tour',
            description: '7 cities in 10 days',
            category: 'Cultural',
            status: 'Archived',
            departureDate: '2024-02-20',
            image: '🏛️'
        },
        {
            id: 'TRP-003',
            title: 'Tropical Paradise',
            description: 'Beach resort getaway',
            category: 'Beach',
            status: 'Inactive',
            departureDate: '2024-04-10',
            image: '🏖️'
        },
        {
            id: 'TRP-004',
            title: 'Tokyo City Break',
            description: 'Modern Japan experience',
            category: 'City Tour',
            status: 'Archived',
            departureDate: '2024-01-25',
            image: '🏙️'
        }
    ];

    const categories = ['All Categories', 'Adventure', 'Cultural', 'Beach', 'City Tour'];
    const statuses = ['All Status', 'Active', 'Inactive', 'Archived'];

    const getStatusColor = (status) => {
        switch (status) {
            case 'Active': return 'bg-green-100 text-green-800';
            case 'Inactive': return 'bg-gray-100 text-gray-800';
            case 'Archived': return 'bg-blue-100 text-blue-800';
            default: return 'bg-gray-100 text-gray-800';
        }
    };

    const getStatusIcon = (status) => {
        switch (status) {
            case 'Active': return <Check className="w-3 h-3" />;
            case 'Inactive': return <Clock className="w-3 h-3" />;
            case 'Archived': return <Info className="w-3 h-3" />;
            default: return <Clock className="w-3 h-3" />;
        }
    };

    const filteredTrips = trips.filter(trip => {
        const matchesSearch = trip.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            trip.description.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesCategory = selectedCategory === 'All Categories' || trip.category === selectedCategory;
        const matchesStatus = selectedStatus === 'All Status' || trip.status === selectedStatus;
        return matchesSearch && matchesCategory && matchesStatus;
    });

    return (
        <div className="min-h-screen bg-gray-50 flex">
            {/* Sidebar */}
            <div className="w-64 bg-white shadow-lg">
                <div className="p-6">
                    <div className="flex items-center space-x-2">
                        <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center">
                            <MapPin className="w-5 h-5 text-white" />
                        </div>
                        <span className="text-xl font-bold text-gray-800">TravelAdmin</span>
                    </div>
                </div>

                <Navbar />
            </div>

            {/* Main Content */}
            <div className="flex-1 flex flex-col">
                {/* Header */}
                <div className="bg-white shadow-sm border-b">
                    <div className="px-8 py-4">
                        <div className="flex items-center justify-between">
                            <div>
                                <h1 className="text-2xl font-bold text-gray-900">Trips Management</h1>
                                <p className="text-sm text-gray-600 mt-1">Manage your travel packages and itineraries</p>
                            </div>
                            <div className="flex items-center space-x-4">
                                <Bell className="w-6 h-6 text-gray-400 cursor-pointer hover:text-gray-600" />
                                <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
                                    <span className="text-white font-semibold text-sm">A</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Content */}
                <div className="flex-1 p-8">
                    {/* Search and Filters */}
                    <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
                        <div className="flex items-center space-x-4 mb-4">
                            <div className="flex-1 relative">
                                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                                <input
                                    type="text"
                                    placeholder="Search trips..."
                                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                />
                            </div>
                            <div className="relative">
                                <select
                                    className="appearance-none bg-white border border-gray-300 rounded-lg px-4 py-2 pr-8 focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                                    value={selectedCategory}
                                    onChange={(e) => setSelectedCategory(e.target.value)}
                                >
                                    {categories.map(category => (
                                        <option key={category} value={category}>{category}</option>
                                    ))}
                                </select>
                                <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4 pointer-events-none" />
                            </div>
                            <div className="relative">
                                <select
                                    className="appearance-none bg-white border border-gray-300 rounded-lg px-4 py-2 pr-8 focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                                    value={selectedStatus}
                                    onChange={(e) => setSelectedStatus(e.target.value)}
                                >
                                    {statuses.map(status => (
                                        <option key={status} value={status}>{status}</option>
                                    ))}
                                </select>
                                <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4 pointer-events-none" />
                            </div>
                            <input
                                type="date"
                                className="border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                            />
                            <button className="bg-orange-500 text-white px-4 py-2 rounded-lg hover:bg-orange-600 flex items-center space-x-2">
                                <Plus className="w-4 h-4" />
                                <span>Add New Trip</span>
                            </button>
                        </div>
                    </div>

                    {/* Trips Table */}
                    <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                        <div className="overflow-x-auto">
                            <table className="w-full">
                                <thead className="bg-gray-50">
                                    <tr>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <div className="flex items-center space-x-1">
                                                <span>Title</span>
                                                <ChevronDown className="w-3 h-3" />
                                            </div>
                                        </th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <div className="flex items-center space-x-1">
                                                <span>Code</span>
                                                <ChevronDown className="w-3 h-3" />
                                            </div>
                                        </th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <div className="flex items-center space-x-1">
                                                <span>Category</span>
                                                <ChevronDown className="w-3 h-3" />
                                            </div>
                                        </th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <div className="flex items-center space-x-1">
                                                <span>Status</span>
                                                <ChevronDown className="w-3 h-3" />
                                            </div>
                                        </th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <div className="flex items-center space-x-1">
                                                <span>Departure Date</span>
                                                <ChevronDown className="w-3 h-3" />
                                            </div>
                                        </th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Actions
                                        </th>
                                    </tr>
                                </thead>
                                <tbody className="bg-white divide-y divide-gray-200">
                                    {filteredTrips.map((trip) => (
                                        <tr key={trip.id} className="hover:bg-gray-50">
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <div className="flex items-center">
                                                    <div className="flex-shrink-0 h-10 w-10">
                                                        <div className="h-10 w-10 rounded-lg bg-gray-100 flex items-center justify-center text-lg">
                                                            {trip.image}
                                                        </div>
                                                    </div>
                                                    <div className="ml-4">
                                                        <div className="text-sm font-medium text-gray-900">{trip.title}</div>
                                                        <div className="text-sm text-gray-500">{trip.description}</div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                {trip.id}
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <div className="relative">
                                                    <select className="appearance-none bg-white border border-gray-300 rounded px-3 py-1 text-sm focus:ring-2 focus:ring-orange-500 focus:border-transparent">
                                                        <option value={trip.category}>{trip.category}</option>
                                                    </select>
                                                    <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 w-3 h-3 pointer-events-none" />
                                                </div>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <div className="relative">
                                                    <select className={`appearance-none border rounded px-3 py-1 text-sm focus:ring-2 focus:ring-orange-500 focus:border-transparent ${getStatusColor(trip.status)}`}>
                                                        <option value={trip.status}>{trip.status}</option>
                                                    </select>
                                                    <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 w-3 h-3 pointer-events-none" />
                                                </div>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <input
                                                    type="date"
                                                    value={trip.departureDate}
                                                    className="border border-gray-300 rounded px-3 py-1 text-sm focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                                                />
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                                <div className="flex items-center space-x-2">
                                                    <button className="text-orange-500 hover:text-orange-700 p-1 rounded">
                                                        <Eye className="w-4 h-4" />
                                                    </button>
                                                    <button className="text-gray-500 hover:text-gray-700 p-1 rounded">
                                                        <Copy className="w-4 h-4" />
                                                    </button>
                                                    <button className="text-red-500 hover:text-red-700 p-1 rounded">
                                                        <Trash2 className="w-4 h-4" />
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>

                        {/* Pagination */}
                        <div className="px-6 py-4 border-t border-gray-200">
                            <div className="flex items-center justify-between">
                                <div className="text-sm text-gray-700">
                                    Showing 1 to 4 of 24 results
                                </div>
                                <div className="flex items-center space-x-2">
                                    <button className="px-3 py-1 rounded-lg border border-gray-300 text-sm hover:bg-gray-50">
                                        Previous
                                    </button>
                                    <button className="px-3 py-1 rounded-lg bg-orange-500 text-white text-sm">
                                        1
                                    </button>
                                    <button className="px-3 py-1 rounded-lg border border-gray-300 text-sm hover:bg-gray-50">
                                        2
                                    </button>
                                    <button className="px-3 py-1 rounded-lg border border-gray-300 text-sm hover:bg-gray-50">
                                        3
                                    </button>
                                    <button className="px-3 py-1 rounded-lg border border-gray-300 text-sm hover:bg-gray-50">
                                        Next
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Trips;