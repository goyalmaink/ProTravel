import React, { useState, useRef } from 'react';
import { Bell, Plus, Check, Upload, Calendar, MapPin, Users, Settings, MessageSquare, Image, FileText, Star, AlertTriangle, Clock, Info, Search, Filter, ChevronDown, Play, Eye } from 'lucide-react';
import Navbar from './Navbar'; // Assuming you have a Navbar component
const Media = () => {
    const [uploadedFiles, setUploadedFiles] = useState([
        {
            id: 1,
            name: 'beach-sunset.jpg',
            type: 'image',
            size: '2.4 MB',
            url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=300&h=200&fit=crop',
            assigned: false
        },
        {
            id: 2,
            name: 'hiking-adventure.mp4',
            type: 'video',
            size: '15.2 MB',
            url: 'https://images.unsplash.com/photo-1551632811-561732d1e306?w=300&h=200&fit=crop',
            assigned: false
        },
        {
            id: 3,
            name: 'travel-guide.pdf',
            type: 'pdf',
            size: '1.8 MB',
            url: null,
            assigned: false
        },
        {
            id: 4,
            name: 'city-night.jpg',
            type: 'image',
            size: '3.1 MB',
            url: 'https://images.unsplash.com/photo-1514565131-fce0801e5785?w=300&h=200&fit=crop',
            assigned: false
        },
        {
            id: 5,
            name: 'gourmet-dish.jpg',
            type: 'image',
            size: '1.9 MB',
            url: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=300&h=200&fit=crop',
            assigned: false
        },
        {
            id: 6,
            name: 'mountain-view.jpg',
            type: 'image',
            size: '4.2 MB',
            url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=300&h=200&fit=crop',
            assigned: false
        }
    ]);

    const [searchQuery, setSearchQuery] = useState('');
    const [mediaFilter, setMediaFilter] = useState('All Media Types');
    const [sortBy, setSortBy] = useState('Sort by Date');
    const [isDragging, setIsDragging] = useState(false);
    const fileInputRef = useRef(null);


    const handleFileUpload = (files) => {
        Array.from(files).forEach(file => {
            if (file.size <= 50 * 1024 * 1024) { // 50MB limit
                const reader = new FileReader();
                reader.onload = (e) => {
                    const newFile = {
                        id: Date.now() + Math.random(),
                        name: file.name,
                        type: file.type.startsWith('image/') ? 'image' :
                            file.type.startsWith('video/') ? 'video' :
                                file.type === 'application/pdf' ? 'pdf' : 'other',
                        size: formatFileSize(file.size),
                        url: file.type.startsWith('image/') ? e.target.result :
                            file.type.startsWith('video/') ? URL.createObjectURL(file) : null,
                        assigned: false
                    };
                    setUploadedFiles(prev => [...prev, newFile]);
                };
                if (file.type.startsWith('image/')) {
                    reader.readAsDataURL(file);
                } else {
                    reader.readAsArrayBuffer(file);
                }
            }
        });
    };

    const formatFileSize = (bytes) => {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
    };

    const handleDragOver = (e) => {
        e.preventDefault();
        setIsDragging(true);
    };

    const handleDragLeave = (e) => {
        e.preventDefault();
        setIsDragging(false);
    };

    const handleDrop = (e) => {
        e.preventDefault();
        setIsDragging(false);
        const files = e.dataTransfer.files;
        handleFileUpload(files);
    };

    const filteredFiles = uploadedFiles.filter(file => {
        const matchesSearch = file.name.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesFilter = mediaFilter === 'All Media Types' ||
            (mediaFilter === 'Images' && file.type === 'image') ||
            (mediaFilter === 'Videos' && file.type === 'video') ||
            (mediaFilter === 'PDFs' && file.type === 'pdf');
        return matchesSearch && matchesFilter;
    });

    const renderFilePreview = (file) => {
        if (file.type === 'image' && file.url) {
            return (
                <div className="relative w-full h-40 bg-gray-100 rounded-lg overflow-hidden">
                    <img src={file.url} alt={file.name} className="w-full h-full object-cover" />
                </div>
            );
        } else if (file.type === 'video') {
            return (
                <div className="relative w-full h-40 bg-gray-800 rounded-lg overflow-hidden flex items-center justify-center">
                    {file.url ? (
                        <video className="w-full h-full object-cover" muted>
                            <source src={file.url} type="video/mp4" />
                        </video>
                    ) : (
                        <div className="w-full h-full bg-gray-300 flex items-center justify-center">
                            <Play className="w-12 h-12 text-gray-600" />
                        </div>
                    )}
                    <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-12 h-12 bg-black bg-opacity-50 rounded-full flex items-center justify-center">
                            <Play className="w-6 h-6 text-white ml-1" />
                        </div>
                    </div>
                </div>
            );
        } else if (file.type === 'pdf') {
            return (
                <div className="w-full h-40 bg-red-50 rounded-lg flex items-center justify-center">
                    <div className="text-center">
                        <div className="w-16 h-20 bg-red-500 rounded-md flex items-center justify-center mb-2 mx-auto">
                            <span className="text-white text-xs font-bold">PDF</span>
                        </div>
                    </div>
                </div>
            );
        }
        return (
            <div className="w-full h-40 bg-gray-100 rounded-lg flex items-center justify-center">
                <FileText className="w-12 h-12 text-gray-400" />
            </div>
        );
    };

    return (
        <div className="min-h-screen bg-gray-50 flex">
            {/* Sidebar */}
            <div className="w-64 bg-white shadow-lg">
                <div className="p-6">
                    <div className="flex items-center space-x-2">
                        <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center">
                            <MapPin className="w-5 h-5 text-white" />
                        </div>
                        <span className="text-xl font-bold text-gray-800">TravelAdmin</span>
                    </div>
                </div>


                <Navbar />
            </div>

            {/* Main Content */}
            <div className="flex-1 flex flex-col">
                {/* Header */}
                <div className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
                    <div className="flex items-center justify-between">
                        <div>
                            <h1 className="text-2xl font-bold text-gray-800">Media Library</h1>
                            <p className="text-gray-600">{uploadedFiles.length} files</p>
                        </div>
                        <button
                            onClick={() => fileInputRef.current?.click()}
                            className="bg-orange-500 text-white px-4 py-2 rounded-lg hover:bg-orange-600 transition-colors flex items-center space-x-2"
                        >
                            <Plus className="w-4 h-4" />
                            <span>Upload Files</span>
                        </button>
                    </div>
                </div>

                {/* Upload Area */}
                <div className="p-6">
                    <div
                        className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${isDragging ? 'border-orange-400 bg-orange-50' : 'border-gray-300 bg-gray-50'
                            }`}
                        onDragOver={handleDragOver}
                        onDragLeave={handleDragLeave}
                        onDrop={handleDrop}
                    >
                        <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <Upload className="w-6 h-6 text-orange-500" />
                        </div>
                        <h3 className="text-lg font-semibold text-gray-800 mb-2">Drop files here to upload</h3>
                        <p className="text-gray-600 mb-4">JPG, PNG, MP4, PDF up to 50MB each</p>
                        <button
                            onClick={() => fileInputRef.current?.click()}
                            className="bg-orange-500 text-white px-6 py-2 rounded-lg hover:bg-orange-600 transition-colors"
                        >
                            Browse Files
                        </button>
                    </div>

                    {/* Hidden File Input */}
                    <input
                        ref={fileInputRef}
                        type="file"
                        multiple
                        accept=".jpg,.jpeg,.png,.mp4,.pdf"
                        onChange={(e) => handleFileUpload(e.target.files)}
                        className="hidden"
                    />
                </div>

                {/* Search and Filter Controls */}
                <div className="px-6 pb-6">
                    <div className="flex items-center space-x-4">
                        <div className="flex-1 relative">
                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                            <input
                                type="text"
                                placeholder="Search by file name or caption..."
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                            />
                        </div>

                        <div className="relative">
                            <select
                                value={mediaFilter}
                                onChange={(e) => setMediaFilter(e.target.value)}
                                className="appearance-none bg-white border border-gray-300 rounded-lg px-4 py-2 pr-8 focus:outline-none focus:ring-2 focus:ring-orange-500"
                            >
                                <option>All Media Types</option>
                                <option>Images</option>
                                <option>Videos</option>
                                <option>PDFs</option>
                            </select>
                            <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                        </div>

                        <div className="relative">
                            <select
                                value={sortBy}
                                onChange={(e) => setSortBy(e.target.value)}
                                className="appearance-none bg-white border border-gray-300 rounded-lg px-4 py-2 pr-8 focus:outline-none focus:ring-2 focus:ring-orange-500"
                            >
                                <option>Sort by Date</option>
                                <option>Sort by Name</option>
                                <option>Sort by Size</option>
                            </select>
                            <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                        </div>

                        <button className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                            <Filter className="w-5 h-5 text-gray-600" />
                        </button>
                    </div>
                </div>

                {/* Media Grid */}
                <div className="flex-1 px-6 pb-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                        {filteredFiles.map((file) => (
                            <div key={file.id} className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow">
                                <div className="relative">
                                    {renderFilePreview(file)}
                                    <div className="absolute top-2 right-2 flex space-x-1">
                                        <button className="w-6 h-6 bg-white bg-opacity-80 rounded-full flex items-center justify-center hover:bg-opacity-100">
                                            <Eye className="w-4 h-4 text-gray-600" />
                                        </button>
                                        <div className="w-6 h-6 bg-white bg-opacity-80 rounded-full flex items-center justify-center">
                                            <input type="checkbox" className="w-3 h-3" />
                                        </div>
                                    </div>
                                    {!file.assigned && (
                                        <div className="absolute top-2 left-2">
                                            <span className="bg-gray-500 text-white text-xs px-2 py-1 rounded">Unassigned</span>
                                        </div>
                                    )}
                                </div>
                                <div className="p-4">
                                    <h3 className="font-medium text-gray-800 truncate">{file.name}</h3>
                                    <p className="text-sm text-gray-600 mt-1">{file.size}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Media;