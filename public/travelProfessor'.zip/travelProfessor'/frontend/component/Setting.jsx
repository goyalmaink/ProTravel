// import React, { useState } from 'react';
import { Bell, Plus, Check, Upload, Calendar, MapPin, Users, Settings, MessageSquare, Image, FileText, Star, AlertTriangle, Clock, Info } from 'lucide-react';
import Navbar from './Navbar'; // Assuming you have a Navbar component
const Setting = () => {


    return (
        <div className="min-h-screen bg-gray-50 flex">
            {/* Sidebar */}
            <div className="w-64 bg-white shadow-lg">
                <div className="p-6">
                    <div className="flex items-center space-x-2">
                        <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center">
                            <MapPin className="w-5 h-5 text-white" />
                        </div>
                        <span className="text-xl font-bold text-gray-800">TravelAdmin</span>
                    </div>
                </div>

                <Navbar />
            </div>



        </div>
    );
};

export default Setting;