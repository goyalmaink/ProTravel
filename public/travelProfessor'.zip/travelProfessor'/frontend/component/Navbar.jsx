import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
    BarChart3,
    Image,
    NotebookPen,
    Users,
    Star, Map,
    Settings,
} from 'lucide-react';

const Navbar = () => {
    const location = useLocation();
    const currentPath = location.pathname;

    const getActiveClass = (path) => {
        return currentPath === path
            ? "flex items-center space-x-3 pr-4 py-3 bg-orange-500 text-white rounded-lg font-medium"
            : "flex items-center space-x-3 pr-4 py-3 text-gray-600 hover:bg-gray-50 rounded-lg transition-colors duration-200";
    };

    return (
        <div className="flex flex-col h-full bg-white">

            <nav className="flex-1 px-4 space-y-1">
                <Link
                    to="/"
                    className={getActiveClass('/')}
                >
                    <BarChart3 className="w-5 h-5" />
                    <span>Dashboard</span>
                </Link>

                <Link
                    to="/trips"
                    className={getActiveClass('/trips')}
                >
                    <Map className="w-5 h-5" />
                    <span>Trips</span>
                </Link>

                <Link
                    to="/media"
                    className={getActiveClass('/media')}
                >
                    <Image className="w-5 h-5" />
                    <span>Media</span>
                </Link>

                <Link
                    to="/blog"
                    className={getActiveClass('/blog')}
                >
                    <NotebookPen className="w-5 h-5" />
                    <span>Blog</span>
                </Link>

                <Link
                    to="/reviews"
                    className={getActiveClass('/reviews')}
                >
                    <Star className="w-5 h-5" />
                    <span>Reviews</span>
                </Link>

                <Link
                    to="/users"
                    className={getActiveClass('/users')}
                >
                    <Users className="w-5 h-5" />
                    <span>Users</span>
                </Link>
                <Link
                    to="/settings"
                    className={getActiveClass('/settings')}
                >
                    <Settings className="w-5 h-5" />
                    <span>Settings</span>
                </Link>
            </nav>
        </div>
    );
};

export default Navbar;