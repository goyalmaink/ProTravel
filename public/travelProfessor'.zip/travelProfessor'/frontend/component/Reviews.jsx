import React, { useState, useEffect } from 'react';
import { Bell, Plus, Check, Upload, Calendar, MapPin, Users, Settings, MessageSquare, Image, FileText, Star, AlertTriangle, Clock, Info, Search, Filter, ChevronDown, Eye, Reply, Flag, ThumbsUp, ThumbsDown, MoreHorizontal, Edit, Trash2, X } from 'lucide-react';
import Navbar from './Navbar'; // Assuming you have a Navbar component
const Reviews = () => {
    const [activeTab, setActiveTab] = useState('all');
    const [searchTerm, setSearchTerm] = useState('');
    const [filterStatus, setFilterStatus] = useState('all');
    const [selectedReview, setSelectedReview] = useState(null);
    const [showReplyModal, setShowReplyModal] = useState(false);
    const [replyText, setReplyText] = useState('');
    const [reviews, setReviews] = useState([
        {
            id: 1,
            customerName: 'Sarah Johnson',
            customerAvatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b77c?w=100&h=100&fit=crop&crop=face',
            rating: 5,
            title: 'Amazing Experience in Bali!',
            content: 'The trip to Bali was absolutely incredible. The hotel was perfect, the tour guide was knowledgeable, and every detail was taken care of. I would definitely book with this company again!',
            destination: 'Bali, Indonesia',
            date: '2024-07-15',
            status: 'published',
            helpful: 12,
            replies: 1,
            flagged: false,
            verified: true
        },
        {
            id: 2,
            customerName: 'Mike Chen',
            customerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
            rating: 4,
            title: 'Great Trip to Paris',
            content: 'Had a wonderful time in Paris. The itinerary was well-planned and the accommodations were comfortable. Only minor issue was the delayed flight, but that was beyond the company\'s control.',
            destination: 'Paris, France',
            date: '2024-07-10',
            status: 'published',
            helpful: 8,
            replies: 0,
            flagged: false,
            verified: true
        },
        {
            id: 3,
            customerName: 'Anonymous User',
            customerAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop&crop=face',
            rating: 2,
            title: 'Poor Service Experience',
            content: 'The service was disappointing. The hotel was not as described and the tour guide was unprofessional. I expected much better for the price paid.',
            destination: 'Rome, Italy',
            date: '2024-07-12',
            status: 'pending',
            helpful: 3,
            replies: 0,
            flagged: true,
            verified: false
        },
        {
            id: 4,
            customerName: 'Emma Williams',
            customerAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face',
            rating: 5,
            title: 'Perfect Honeymoon Trip',
            content: 'Our honeymoon in Maldives was absolutely perfect! Every detail was taken care of, from the romantic dinner setups to the private beach access. Thank you for making our special time unforgettable.',
            destination: 'Maldives',
            date: '2024-07-08',
            status: 'published',
            helpful: 25,
            replies: 2,
            flagged: false,
            verified: true
        },
        {
            id: 5,
            customerName: 'David Miller',
            customerAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
            rating: 3,
            title: 'Average Experience',
            content: 'The trip was okay, nothing special. The destinations were beautiful but the organization could have been better. Some activities were cancelled last minute.',
            destination: 'Thailand',
            date: '2024-07-05',
            status: 'published',
            helpful: 5,
            replies: 1,
            flagged: false,
            verified: true
        }
    ]);

  

    const StarRating = ({ rating, size = 'w-4 h-4' }) => (
        <div className="flex">
            {[1, 2, 3, 4, 5].map((star) => (
                <Star
                    key={star}
                    className={`${size} ${star <= rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
                />
            ))}
        </div>
    );

    const filteredReviews = reviews.filter(review => {
        const matchesSearch = review.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            review.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            review.destination.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesStatus = filterStatus === 'all' || review.status === filterStatus;
        const matchesTab = activeTab === 'all' || 
                         (activeTab === 'flagged' && review.flagged) ||
                         (activeTab === 'pending' && review.status === 'pending') ||
                         (activeTab === 'published' && review.status === 'published');
        
        return matchesSearch && matchesStatus && matchesTab;
    });

    const handleStatusChange = (reviewId, newStatus) => {
        setReviews(reviews.map(review => 
            review.id === reviewId ? { ...review, status: newStatus } : review
        ));
    };

    const handleFlag = (reviewId) => {
        setReviews(reviews.map(review => 
            review.id === reviewId ? { ...review, flagged: !review.flagged } : review
        ));
    };

    const handleReply = (reviewId) => {
        setSelectedReview(reviewId);
        setShowReplyModal(true);
    };

    const submitReply = () => {
        if (replyText.trim()) {
            setReviews(reviews.map(review => 
                review.id === selectedReview ? { ...review, replies: review.replies + 1 } : review
            ));
            setReplyText('');
            setShowReplyModal(false);
            setSelectedReview(null);
        }
    };

    const getStatusColor = (status) => {
        switch (status) {
            case 'published': return 'bg-green-100 text-green-800';
            case 'pending': return 'bg-yellow-100 text-yellow-800';
            case 'rejected': return 'bg-red-100 text-red-800';
            default: return 'bg-gray-100 text-gray-800';
        }
    };

    const stats = {
        total: reviews.length,
        published: reviews.filter(r => r.status === 'published').length,
        pending: reviews.filter(r => r.status === 'pending').length,
        flagged: reviews.filter(r => r.flagged).length,
        avgRating: (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
    };

    return (
        <div className="min-h-screen bg-gray-50 flex">
            {/* Sidebar */}
            <div className="w-64 bg-white shadow-lg">
                <div className="p-6">
                    <div className="flex items-center space-x-2">
                        <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center">
                            <MapPin className="w-5 h-5 text-white" />
                        </div>
                        <span className="text-xl font-bold text-gray-800">TravelAdmin</span>
                    </div>
                </div>
                <Navbar />
            </div>

            {/* Main Content */}
            <div className="flex-1 overflow-hidden">
                {/* Header */}
                <div className="bg-white shadow-sm border-b">
                    <div className="px-6 py-4 flex items-center justify-between">
                        <div>
                            <h1 className="text-2xl font-bold text-gray-900">Reviews Management</h1>
                            <p className="text-gray-600">Manage customer reviews and feedback</p>
                        </div>
                        <div className="flex items-center space-x-4">
                            <div className="relative">
                                <Bell className="w-6 h-6 text-gray-600" />
                                <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>
                            </div>
                            <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
                                <span className="text-white font-semibold">A</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Stats Cards */}
                <div className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
                        <div className="bg-white p-4 rounded-lg shadow-sm">
                            <div className="text-sm text-gray-600">Total Reviews</div>
                            <div className="text-2xl font-bold text-gray-900">{stats.total}</div>
                        </div>
                        <div className="bg-white p-4 rounded-lg shadow-sm">
                            <div className="text-sm text-gray-600">Published</div>
                            <div className="text-2xl font-bold text-green-600">{stats.published}</div>
                        </div>
                        <div className="bg-white p-4 rounded-lg shadow-sm">
                            <div className="text-sm text-gray-600">Pending</div>
                            <div className="text-2xl font-bold text-yellow-600">{stats.pending}</div>
                        </div>
                        <div className="bg-white p-4 rounded-lg shadow-sm">
                            <div className="text-sm text-gray-600">Flagged</div>
                            <div className="text-2xl font-bold text-red-600">{stats.flagged}</div>
                        </div>
                        <div className="bg-white p-4 rounded-lg shadow-sm">
                            <div className="text-sm text-gray-600">Avg Rating</div>
                            <div className="flex items-center space-x-2">
                                <div className="text-2xl font-bold text-gray-900">{stats.avgRating}</div>
                                <StarRating rating={Math.round(stats.avgRating)} />
                            </div>
                        </div>
                    </div>

                    {/* Filters and Search */}
                    <div className="bg-white rounded-lg shadow-sm mb-6">
                        <div className="p-4 border-b">
                            <div className="flex items-center justify-between">
                                <div className="flex space-x-6">
                                    <button
                                        onClick={() => setActiveTab('all')}
                                        className={`px-4 py-2 rounded-lg ${activeTab === 'all' ? 'bg-orange-500 text-white' : 'text-gray-600 hover:bg-gray-100'}`}
                                    >
                                        All Reviews
                                    </button>
                                    <button
                                        onClick={() => setActiveTab('pending')}
                                        className={`px-4 py-2 rounded-lg ${activeTab === 'pending' ? 'bg-orange-500 text-white' : 'text-gray-600 hover:bg-gray-100'}`}
                                    >
                                        Pending ({stats.pending})
                                    </button>
                                    <button
                                        onClick={() => setActiveTab('published')}
                                        className={`px-4 py-2 rounded-lg ${activeTab === 'published' ? 'bg-orange-500 text-white' : 'text-gray-600 hover:bg-gray-100'}`}
                                    >
                                        Published ({stats.published})
                                    </button>
                                    <button
                                        onClick={() => setActiveTab('flagged')}
                                        className={`px-4 py-2 rounded-lg ${activeTab === 'flagged' ? 'bg-orange-500 text-white' : 'text-gray-600 hover:bg-gray-100'}`}
                                    >
                                        Flagged ({stats.flagged})
                                    </button>
                                </div>
                                <div className="flex items-center space-x-4">
                                    <div className="relative">
                                        <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
                                        <input
                                            type="text"
                                            placeholder="Search reviews..."
                                            className="pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                                            value={searchTerm}
                                            onChange={(e) => setSearchTerm(e.target.value)}
                                        />
                                    </div>
                                    <select
                                        className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                                        value={filterStatus}
                                        onChange={(e) => setFilterStatus(e.target.value)}
                                    >
                                        <option value="all">All Status</option>
                                        <option value="published">Published</option>
                                        <option value="pending">Pending</option>
                                        <option value="rejected">Rejected</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        {/* Reviews List */}
                        <div className="divide-y">
                            {filteredReviews.map((review) => (
                                <div key={review.id} className="p-6 hover:bg-gray-50">
                                    <div className="flex items-start space-x-4">
                                        <img
                                            src={review.customerAvatar}
                                            alt={review.customerName}
                                            className="w-12 h-12 rounded-full"
                                        />
                                        <div className="flex-1">
                                            <div className="flex items-center justify-between mb-2">
                                                <div className="flex items-center space-x-3">
                                                    <h3 className="font-semibold text-gray-900">{review.customerName}</h3>
                                                    {review.verified && (
                                                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800">
                                                            <Check className="w-3 h-3 mr-1" />
                                                            Verified
                                                        </span>
                                                    )}
                                                    <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(review.status)}`}>
                                                        {review.status}
                                                    </span>
                                                    {review.flagged && (
                                                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-red-100 text-red-800">
                                                            <Flag className="w-3 h-3 mr-1" />
                                                            Flagged
                                                        </span>
                                                    )}
                                                </div>
                                                <div className="flex items-center space-x-2">
                                                    <StarRating rating={review.rating} />
                                                    <span className="text-sm text-gray-500">{review.date}</span>
                                                </div>
                                            </div>
                                            <p className="text-sm text-gray-600 mb-1">{review.destination}</p>
                                            <h4 className="font-medium text-gray-900 mb-2">{review.title}</h4>
                                            <p className="text-gray-700 mb-3">{review.content}</p>
                                            <div className="flex items-center justify-between">
                                                <div className="flex items-center space-x-4 text-sm text-gray-500">
                                                    <span className="flex items-center">
                                                        <ThumbsUp className="w-4 h-4 mr-1" />
                                                        {review.helpful} helpful
                                                    </span>
                                                    <span className="flex items-center">
                                                        <MessageSquare className="w-4 h-4 mr-1" />
                                                        {review.replies} replies
                                                    </span>
                                                </div>
                                                <div className="flex items-center space-x-2">
                                                    <button
                                                        onClick={() => handleReply(review.id)}
                                                        className="px-3 py-1 text-sm bg-blue-100 text-blue-800 rounded-lg hover:bg-blue-200"
                                                    >
                                                        <Reply className="w-4 h-4 mr-1 inline" />
                                                        Reply
                                                    </button>
                                                    <button
                                                        onClick={() => handleFlag(review.id)}
                                                        className={`px-3 py-1 text-sm rounded-lg ${review.flagged ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800'} hover:bg-opacity-80`}
                                                    >
                                                        <Flag className="w-4 h-4 mr-1 inline" />
                                                        {review.flagged ? 'Unflag' : 'Flag'}
                                                    </button>
                                                    {review.status === 'pending' && (
                                                        <>
                                                            <button
                                                                onClick={() => handleStatusChange(review.id, 'published')}
                                                                className="px-3 py-1 text-sm bg-green-100 text-green-800 rounded-lg hover:bg-green-200"
                                                            >
                                                                <Check className="w-4 h-4 mr-1 inline" />
                                                                Approve
                                                            </button>
                                                            <button
                                                                onClick={() => handleStatusChange(review.id, 'rejected')}
                                                                className="px-3 py-1 text-sm bg-red-100 text-red-800 rounded-lg hover:bg-red-200"
                                                            >
                                                                <X className="w-4 h-4 mr-1 inline" />
                                                                Reject
                                                            </button>
                                                        </>
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Reply Modal */}
                {showReplyModal && (
                    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                        <div className="bg-white rounded-lg p-6 w-full max-w-md">
                            <div className="flex items-center justify-between mb-4">
                                <h3 className="text-lg font-semibold">Reply to Review</h3>
                                <button
                                    onClick={() => setShowReplyModal(false)}
                                    className="text-gray-500 hover:text-gray-700"
                                >
                                    <X className="w-5 h-5" />
                                </button>
                            </div>
                            <textarea
                                value={replyText}
                                onChange={(e) => setReplyText(e.target.value)}
                                placeholder="Write your reply..."
                                className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 mb-4"
                                rows="4"
                            />
                            <div className="flex justify-end space-x-3">
                                <button
                                    onClick={() => setShowReplyModal(false)}
                                    className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
                                >
                                    Cancel
                                </button>
                                <button
                                    onClick={submitReply}
                                    className="px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600"
                                >
                                    Send Reply
                                </button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Reviews;