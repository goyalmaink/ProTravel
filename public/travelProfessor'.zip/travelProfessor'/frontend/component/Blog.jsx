import React, { useState } from 'react';
import { 
  Bell, Plus, Check, Upload, Calendar, MapPin, Users, Settings, 
  MessageSquare, Image, FileText, Star, AlertTriangle, Clock, 
  Info, Search, Edit, Trash2, MoreHorizontal, CheckCircle, 
  Award, Heart, Globe, Home, Move, Save, X 
} from 'lucide-react';
import Navbar from './Navbar'; 

const Blog = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [pageFilter, setPageFilter] = useState('All Pages');
  const [reorderingEnabled, setReorderingEnabled] = useState(false);
  const [activeSection, setActiveSection] = useState('Dashboard');
  const [isAddingCard, setIsAddingCard] = useState(false);
  const [editingCard, setEditingCard] = useState(null);
  const [draggedCard, setDraggedCard] = useState(null);
  
  const [cards, setCards] = useState([
    {
      id: 1,
      title: '100% Verified Trips',
      description: 'All our trips are thoroughly verified and approved by local experts.',
      icon: <CheckCircle className="w-8 h-8 text-green-500" />,
      status: 'Active',
      tags: [
        { name: 'Home Page', color: 'blue' },
        { name: 'Trust Badge', color: 'purple' }
      ],
      backgroundColor: 'bg-green-50'
    },
    {
      id: 2,
      title: 'Expert Guides',
      description: 'Our trips are led by experienced locals who know every hidden gem.',
      icon: <Users className="w-8 h-8 text-blue-500" />,
      status: 'Active',
      tags: [
        { name: 'Global', color: 'green' },
        { name: 'Feature', color: 'orange' }
      ],
      backgroundColor: 'bg-blue-50'
    },
    {
      id: 3,
      title: '24/7 Support',
      description: 'Round-the-clock customer support for all your travel needs.',
      icon: <Clock className="w-8 h-8 text-yellow-500" />,
      status: 'Inactive',
      tags: [
        { name: 'Trips', color: 'blue' },
        { name: 'Trust Badge', color: 'purple' }
      ],
      backgroundColor: 'bg-yellow-50'
    },
    {
      id: 4,
      title: '5-Star Rated',
      description: 'Consistently rated 5 stars by thousands of happy travelers.',
      icon: <Star className="w-8 h-8 text-purple-500" />,
      status: 'Active',
      tags: [
        { name: 'Home Page', color: 'blue' },
        { name: 'Highlight', color: 'green' }
      ],
      backgroundColor: 'bg-purple-50'
    },
    {
      id: 5,
      title: 'Loved by Travelers',
      description: 'Join thousands of satisfied customers who love our service.',
      icon: <Heart className="w-8 h-8 text-red-500" />,
      status: 'Active',
      tags: [
        { name: 'About Us', color: 'green' },
        { name: 'Trust Badge', color: 'purple' }
      ],
      backgroundColor: 'bg-red-50'
    },
    {
      id: 6,
      title: 'Award Winning',
      description: 'Recognized with multiple industry awards for excellence.',
      icon: <Award className="w-8 h-8 text-orange-500" />,
      status: 'Inactive',
      tags: [
        { name: 'Global', color: 'green' },
        { name: 'Feature', color: 'orange' }
      ],
      backgroundColor: 'bg-orange-50'
    }
  ]);

  const [newCard, setNewCard] = useState({
    title: '',
    description: '',
    status: 'Active',
    tags: [],
    backgroundColor: 'bg-blue-50'
  });

 

  const getTagColor = (color) => {
    const colors = {
      blue: 'bg-blue-100 text-blue-800',
      purple: 'bg-purple-100 text-purple-800',
      green: 'bg-green-100 text-green-800',
      orange: 'bg-orange-100 text-orange-800',
      red: 'bg-red-100 text-red-800'
    };
    return colors[color] || 'bg-gray-100 text-gray-800';
  };

  const filteredCards = cards.filter(card => {
    const matchesSearch = card.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         card.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || card.status === statusFilter;
    const matchesPage = pageFilter === 'All Pages' || card.tags.some(tag => tag.name === pageFilter);
    return matchesSearch && matchesStatus && matchesPage;
  });

  // Sidebar Navigation Handler
  const handleMenuClick = (menuName) => {
    setActiveSection(menuName);
    console.log(`Navigated to ${menuName}`);
  };

  // Add New Card Handler
  const handleAddCard = () => {
    setIsAddingCard(true);
    setNewCard({
      title: '',
      description: '',
      status: 'Active',
      tags: [],
      backgroundColor: 'bg-blue-50'
    });
  };

  const saveNewCard = () => {
    if (newCard.title.trim() && newCard.description.trim()) {
      const cardToAdd = {
        id: Math.max(...cards.map(c => c.id)) + 1,
        ...newCard,
        icon: <CheckCircle className="w-8 h-8 text-blue-500" />,
        tags: newCard.tags.length > 0 ? newCard.tags : [{ name: 'General', color: 'blue' }]
      };
      setCards([...cards, cardToAdd]);
      setIsAddingCard(false);
      console.log('New card added:', cardToAdd);
    }
  };

  const cancelAddCard = () => {
    setIsAddingCard(false);
    setNewCard({
      title: '',
      description: '',
      status: 'Active',
      tags: [],
      backgroundColor: 'bg-blue-50'
    });
  };

  // Edit Card Handler
  const handleEditCard = (cardId) => {
    const card = cards.find(c => c.id === cardId);
    setEditingCard({ ...card });
    console.log('Editing card:', card);
  };

  const saveEditCard = () => {
    setCards(cards.map(card => 
      card.id === editingCard.id ? editingCard : card
    ));
    setEditingCard(null);
    console.log('Card updated:', editingCard);
  };

  const cancelEditCard = () => {
    setEditingCard(null);
  };

  // Delete Card Handler
  const handleDeleteCard = (cardId) => {
    if (window.confirm('Are you sure you want to delete this card?')) {
      setCards(cards.filter(card => card.id !== cardId));
      console.log('Card deleted:', cardId);
    }
  };

  // Toggle Card Status
  const toggleCardStatus = (cardId) => {
    setCards(cards.map(card => 
      card.id === cardId 
        ? { ...card, status: card.status === 'Active' ? 'Inactive' : 'Active' }
        : card
    ));
    console.log('Card status toggled:', cardId);
  };

  // Reordering Handler
  const handleReorderToggle = () => {
    setReorderingEnabled(!reorderingEnabled);
    console.log('Reordering enabled:', !reorderingEnabled);
  };

  // Drag and Drop Handlers
  const handleDragStart = (e, cardId) => {
    setDraggedCard(cardId);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const handleDrop = (e, targetCardId) => {
    e.preventDefault();
    if (draggedCard && draggedCard !== targetCardId) {
      const draggedIndex = cards.findIndex(card => card.id === draggedCard);
      const targetIndex = cards.findIndex(card => card.id === targetCardId);
      
      const newCards = [...cards];
      const draggedCardData = newCards[draggedIndex];
      newCards.splice(draggedIndex, 1);
      newCards.splice(targetIndex, 0, draggedCardData);
      
      setCards(newCards);
      console.log('Cards reordered');
    }
    setDraggedCard(null);
  };

  // Filter Reset Handler
  const resetFilters = () => {
    setSearchTerm('');
    setStatusFilter('All');
    setPageFilter('All Pages');
    console.log('Filters reset');
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-lg">
        <div className="p-6">
          <div className="flex items-center space-x-2 cursor-pointer" onClick={() => console.log('Logo clicked')}>
            <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center">
              <Globe className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-gray-800">TravelAdmin</span>
          </div>
        </div>

        <Navbar/>
        
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="bg-white shadow-sm border-b">
          <div className="flex items-center justify-between px-8 py-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-800">Cards / Bento Cards Management</h1>
              <p className="text-gray-600 mt-1">Manage and organize your site cards and badges</p>
            </div>
            <button 
              onClick={handleAddCard}
              className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Card</span>
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white border-b px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search cards by title or type..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent w-80"
                />
              </div>
              
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-600">Status:</span>
                <select 
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-orange-500"
                >
                  <option value="All">All</option>
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                </select>
              </div>
              
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-600">Page:</span>
                <select 
                  value={pageFilter}
                  onChange={(e) => setPageFilter(e.target.value)}
                  className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-orange-500"
                >
                  <option value="All Pages">All Pages</option>
                  <option value="Home Page">Home Page</option>
                  <option value="About Us">About Us</option>
                  <option value="Global">Global</option>
                  <option value="Trips">Trips</option>
                </select>
              </div>
              
              <button 
                onClick={resetFilters}
                className="text-gray-500 hover:text-gray-700 text-sm px-3 py-2 border border-gray-300 rounded-lg"
              >
                Reset
              </button>
            </div>
            
            <div className="flex items-center space-x-2">
              <button 
                onClick={handleReorderToggle}
                className={`flex items-center space-x-1 px-3 py-2 rounded-lg transition-colors ${
                  reorderingEnabled 
                    ? 'bg-orange-100 text-orange-600' 
                    : 'text-orange-500 hover:text-orange-600'
                }`}
              >
                <Move className="w-4 h-4" />
                <span>{reorderingEnabled ? 'Disable' : 'Enable'} Reordering</span>
              </button>
            </div>
          </div>
        </div>

        {/* Cards Grid */}
        <div className="flex-1 p-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Add New Card Form */}
            {isAddingCard && (
              <div className="bg-white rounded-lg p-6 shadow-sm border-2 border-dashed border-orange-300">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Add New Card</h3>
                <div className="space-y-4">
                  <input
                    type="text"
                    placeholder="Card Title"
                    value={newCard.title}
                    onChange={(e) => setNewCard({...newCard, title: e.target.value})}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                  <textarea
                    placeholder="Card Description"
                    value={newCard.description}
                    onChange={(e) => setNewCard({...newCard, description: e.target.value})}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 h-20 resize-none"
                  />
                  <select
                    value={newCard.status}
                    onChange={(e) => setNewCard({...newCard, status: e.target.value})}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                  >
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                  </select>
                  <div className="flex space-x-2">
                    <button
                      onClick={saveNewCard}
                      className="flex-1 bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-lg flex items-center justify-center space-x-2 transition-colors"
                    >
                      <Save className="w-4 h-4" />
                      <span>Save</span>
                    </button>
                    <button
                      onClick={cancelAddCard}
                      className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-700 px-4 py-2 rounded-lg flex items-center justify-center space-x-2 transition-colors"
                    >
                      <X className="w-4 h-4" />
                      <span>Cancel</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Existing Cards */}
            {filteredCards.map((card) => (
              <div 
                key={card.id} 
                className={`${card.backgroundColor} rounded-lg p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow ${
                  reorderingEnabled ? 'cursor-move' : ''
                }`}
                draggable={reorderingEnabled}
                onDragStart={(e) => handleDragStart(e, card.id)}
                onDragOver={handleDragOver}
                onDrop={(e) => handleDrop(e, card.id)}
              >
                {editingCard && editingCard.id === card.id ? (
                  // Edit Mode
                  <div className="space-y-4">
                    <input
                      type="text"
                      value={editingCard.title}
                      onChange={(e) => setEditingCard({...editingCard, title: e.target.value})}
                      className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                    />
                    <textarea
                      value={editingCard.description}
                      onChange={(e) => setEditingCard({...editingCard, description: e.target.value})}
                      className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 h-20 resize-none"
                    />
                    <div className="flex space-x-2">
                      <button
                        onClick={saveEditCard}
                        className="flex-1 bg-green-500 hover:bg-green-600 text-white px-3 py-2 rounded-lg flex items-center justify-center space-x-1 transition-colors"
                      >
                        <Save className="w-4 h-4" />
                        <span>Save</span>
                      </button>
                      <button
                        onClick={cancelEditCard}
                        className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-700 px-3 py-2 rounded-lg flex items-center justify-center space-x-1 transition-colors"
                      >
                        <X className="w-4 h-4" />
                        <span>Cancel</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  // Display Mode
                  <>
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        {card.icon}
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => toggleCardStatus(card.id)}
                            className={`px-2 py-1 text-xs rounded-full cursor-pointer transition-colors ${
                              card.status === 'Active' 
                                ? 'bg-green-100 text-green-800 hover:bg-green-200' 
                                : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                            }`}
                          >
                            {card.status}
                          </button>
                          <button 
                            className="text-gray-400 hover:text-gray-600"
                            onClick={() => console.log('More options for card:', card.id)}
                          >
                            <MoreHorizontal className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                    
                    <h3 className="text-lg font-semibold text-gray-800 mb-2">{card.title}</h3>
                    <p className="text-gray-600 text-sm mb-4">{card.description}</p>
                    
                    <div className="flex flex-wrap gap-2 mb-4">
                      {card.tags.map((tag, index) => (
                        <span key={index} className={`px-2 py-1 text-xs rounded-full ${getTagColor(tag.color)}`}>
                          {tag.name}
                        </span>
                      ))}
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <button 
                        onClick={() => handleEditCard(card.id)}
                        className="text-blue-500 hover:text-blue-600 flex items-center space-x-1 text-sm transition-colors"
                      >
                        <Edit className="w-4 h-4" />
                        <span>Edit</span>
                      </button>
                      <button 
                        onClick={() => handleDeleteCard(card.id)}
                        className="text-red-500 hover:text-red-600 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Blog;